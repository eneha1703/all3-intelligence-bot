# News Radar Run Audit

- pipeline_run_id: `c8d2909766074c51afda22aa2f3e5c90`
- commit_sha: `d95f6adbfa3fa323df44b5cf25860de565892e43`
- db_artifact_reference: `radar-db-25670857528`

## Summary Counters

- collected: `311`
- normalized: `311`
- fresh: `88`
- canonical_events: `304`
- shortlisted: `8`
- sent: `1`
- send_skips: `0`
- failed_sources: `0`
- duration_seconds: `92.15`

## Stage Counters

| Counter | Value |
| --- | --- |
| historical_items_loaded | 311 |
| contexts_count | 311 |
| shortlisted_count | 8 |
| claude_editorial_attempted | 6 |
| claude_editorial_rejected | 4 |
| claude_editorial_fallback | 1 |
| claude_editorial_fallback_low_or_medium_confidence | 1 |
| claude_editorial_promoted | 1 |
| claude_final_card_attempted | 2 |
| claude_final_card_used | 1 |
| claude_final_card_rejected | 1 |

## Stage Timings

| Stage | Duration Seconds |
| --- | --- |
| normalization_and_freshness | 0.857 |
| historical_dedupe_load | 0.016 |
| competitor_matching | 0.028 |
| historical_competitor_count_load | 0.093 |
| canonical_clustering | 1.205 |
| canonical_event_writes | 0.416 |
| ranking_and_sent_history | 1.543 |
| summary_generation | 1.315 |
| editorial_and_late_dedupe | 0.008 |
| delivery | 1.414 |
| decision_persistence | 0.419 |
| run_finalize_and_audit | 0.006 |

## Skip Reason Counts

- `already_sent_canonical_event`: `1`
- `claude_editorial_rejected`: `4`
- `claude_final_card_rejected`: `1`
- `duplicate_canonical_event`: `7`
- `editorial_not_telegram_worthy`: `2`
- `freshness_failed`: `216`
- `no_clear_all3_scope`: `65`
- `obvious_off_scope`: `14`

## Duplicate Suppression Counts

- `already_sent_same_funding_event`: `0`
- `already_sent_same_deployment_event`: `0`
- `duplicate_same_event_shortlist`: `0`
- `duplicate_same_partnership_event_shortlist`: `0`
- `duplicate_same_product_launch_event_shortlist`: `0`

## Send-Stage Problem Counts

- `weak_or_empty_telegram_card`: `0`
- `telegram_send_failed`: `0`

## Sent Items

| Title | Source | Canonical URL |
| --- | --- | --- |
| Indian Construction Robotics Startup Flo Mobility Raises $2.5M in Funding | ai_insider_rss | https://theaiinsider.tech/2026/05/11/indian-construction-robotics-startup-flo-mobility-raises-2-5m-in-funding/ |

## Source Failures

| Source ID | Source Name | Status/Error | Items Collected | Duration Seconds |
| --- | --- | --- | --- | --- |

| none | none | none | none | none |

## Source Collection Counts

| Source ID | Collected Items | Duration Seconds |
| --- | --- | --- |
| techcrunch_rss | 20 | 0.147 |
| tech_funding_news_rss | 10 | 0.803 |
| robot_report_rss | 15 | 0.159 |
| construction_dive_rss | 10 | 0.207 |
| robotics_automation_news_rss | 15 | 1.117 |
| tech_eu_rss | 20 | 0.493 |
| ai_insider_rss | 9 | 0.207 |
| construction_briefing_rss | 0 | 3.855 |
| haufe_immobilien_listing | 10 | 16.013 |
| telegraph_feed | 120 | 0.454 |
| construction_news_intelligence_listing | 10 | 18.977 |
| business_insider_feed | 20 | 0.453 |
| destatis_press_listing | 10 | 1.022 |
| interesting_engineering_rss | 10 | 4.105 |
| wood_central_api | 20 | 1.03 |
| humanoid_robotics_technology_listing | 12 | 2.692 |